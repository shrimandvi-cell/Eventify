const bookingForm = document.getElementById("bookingForm");
const bookingMessage = document.getElementById("bookingMessage");

bookingForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const tickets = document.getElementById("tickets").value;

    bookingMessage.innerHTML =
        "Booking Successful! 🎉<br>" +
        "Thank you, " + name + "! " +
        "Your " + tickets + " ticket(s) have been reserved.";
});